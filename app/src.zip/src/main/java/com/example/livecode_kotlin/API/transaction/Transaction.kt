package com.example.livecode_kotlin.API.transaction

class Transaction(
    var id: String = "",
    var date: String = "",
    var amount: String = ""
)