package com.example.livecode_kotlin.API.user

class User(
    var id: String = "",
    var name: String = "",
    var balance: String = ""
)